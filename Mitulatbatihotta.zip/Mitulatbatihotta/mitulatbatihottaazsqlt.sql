-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2025. Dec 11. 11:12
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `mitulatbatihotta`
--
CREATE DATABASE IF NOT EXISTS `mitulatbatihotta` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `mitulatbatihotta`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `versenyzok`
--

CREATE TABLE `versenyzok` (
  `id` int(11) NOT NULL,
  `nev` varchar(100) NOT NULL,
  `pont1` double NOT NULL,
  `ido1` double NOT NULL,
  `pont2` double NOT NULL,
  `ido2` double NOT NULL,
  `pont3` double NOT NULL,
  `ido3` double NOT NULL,
  `legjobbpont` int(11) NOT NULL,
  `pillhely` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `versenyzok`
--

INSERT INTO `versenyzok` (`id`, `nev`, `pont1`, `ido1`, `pont2`, `ido2`, `pont3`, `ido3`, `legjobbpont`, `pillhely`) VALUES
(1, 'Kovacs Bela', 6, 4.12, 8, 2.01, 3, 7.02, 8, 5),
(2, 'Nagy Arpad', 9, 1.11, 5, 5.02, 7, 3.44, 9, 2),
(3, 'Szabo Tamas', 4, 6.22, 0, 10, 2, 8.31, 4, 9),
(4, 'Varga Imre', 7, 3.21, 6, 4.09, 9, 1.55, 9, 3),
(5, 'Toth Gergely', 3, 7.01, 4, 6.12, 0, 10, 4, 8),
(6, 'Kis Balint', 8, 2.44, 9, 1.87, 6, 4.55, 9, 4),
(7, 'Horvath Levente', 5, 5.11, 3, 7.44, 4, 6.01, 5, 7),
(8, 'Farkas Dominik', 2, 8.13, 1, 8.99, 3, 7.44, 3, 10),
(9, 'Lakatos Daniel', 10, 0.55, 8, 2.12, 7, 3.01, 10, 1),
(10, 'Molnar Lajos', 6, 4.77, 7, 3.11, 8, 2.02, 8, 6);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `versenyzok`
--
ALTER TABLE `versenyzok`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
